package org.systempro.project.coolShaders;

import org.systempro.project.BasicScreen;

public class TestScreen extends BasicScreen {



    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {

    }

    @Override
    public void dispose() {

    }
}
