package org.systempro.project.scalaui

case class Key[A](var widget:A=null);
