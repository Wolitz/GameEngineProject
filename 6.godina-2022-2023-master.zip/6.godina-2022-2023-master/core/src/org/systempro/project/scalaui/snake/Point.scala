package org.systempro.project.scalaui.snake

case class Point(var x:Int=0, var y:Int=0)
