package org.systempro.project.platformer;

public class CameraController {
    
}