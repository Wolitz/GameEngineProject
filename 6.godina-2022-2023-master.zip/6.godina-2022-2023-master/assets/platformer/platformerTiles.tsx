<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="platformerTiles" tilewidth="18" tileheight="18" tilecount="126" columns="16">
 <grid orientation="orthogonal" width="16" height="16"/>
 <image source="platformerTiles.png" width="288" height="126"/>
</tileset>
