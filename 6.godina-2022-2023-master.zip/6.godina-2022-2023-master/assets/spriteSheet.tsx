<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="spriteSheet" tilewidth="16" tileheight="16" tilecount="132" columns="12">
 <image source="./spriteSheet.png" width="192" height="176"/>
</tileset>
